﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 抽奖
{
    class Class1
    {
        //存放幸运号码
        public static int number_size=42;
        public int[] number = new int[number_size];

        //对应相片
        public string[] pic_name = new string[number_size];
    }
}
